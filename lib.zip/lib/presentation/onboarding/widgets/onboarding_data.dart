import 'package:Privio/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';
import 'package:Privio/constant/app_color.dart';
import 'package:Privio/generated/app_localizations.dart';

import 'language_btn_onboarding.dart';

class OnboardingData {
  final String title;
  final String description;
  final String image;
  final Widget? bottomWidget;

  OnboardingData({
    required this.title,
    required this.description,
    required this.image,
    this.bottomWidget,
  });
}

List<OnboardingData> getOnboardingPages(BuildContext context) {
  final l10n = AppLocalizations.of(context);
  final isDark=context.isDark;

  return [
    OnboardingData(
      title: l10n.onboardingTitle4,
      description: l10n.onboardingDesc4,
      image: isDark ?'assets/utils/pageDark1.png' :'assets/utils/pageLight1.png',
      // bottomWidget: LanguageBtnOnboarding(),
    ),

    OnboardingData(
      title: l10n.onboardingTitle1,
      description: l10n.onboardingDesc1,
      image: isDark ?'assets/utils/pageDark2.png' :'assets/utils/pageLight2.png',
    ),
    OnboardingData(
      title: l10n.onboardingTitle2,
      description: l10n.onboardingDesc2,
      image: isDark ?'assets/utils/pageDark3.png' :'assets/utils/pageLight3.png',
    ),

  ];
}
