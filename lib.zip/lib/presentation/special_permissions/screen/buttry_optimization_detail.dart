import 'package:flutter/material.dart';
import 'package:permissions_app/constant/app_color.dart';
import 'package:permissions_app/constant/app_style.dart';
import 'package:permissions_app/constant/risk_level.dart';
import 'package:permissions_app/core/servises/app_special_permiision_service.dart';
import 'package:permissions_app/presentation/special_permissions/widget/helper_widgets.dart';
import 'package:permissions_app/presentation/utils/app_size.dart';
import 'package:permissions_app/presentation/utils/base_screen.dart';

class BatteryOptimizationDetail extends StatelessWidget {
  const BatteryOptimizationDetail({super.key});

  RiskLevel _levelFromIgnoring(bool ignoring) {
    return ignoring ? RiskLevel.mediumRisk : RiskLevel.noRisk;
  }

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      child: Padding(
        padding: EdgeInsets.all(AppSize.width * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle('Battery Optimization'),
            paragraph(
              'Some apps can ignore battery optimizations and continue running '
                  'in the background, which may increase battery usage.',
            ),

            SizedBox(height: AppSize.height * 0.02),

            FutureBuilder<bool>(
              future: AppSpecialPermissionPlatform().isIgnoringBatteryOptimizations(),
              builder: (context, snapshot) {
                final ignoring = snapshot.data ?? false;
                return riskBadge(level: _levelFromIgnoring(ignoring));
              },
            ),

            SizedBox(height: AppSize.height * 0.03),

            GestureDetector(
              onTap: () {
                AppSpecialPermissionPlatform().openBatteryOptimizationSettings();
              },
              child: Container(
                width: double.infinity,
                height: AppSize.height * 0.06,
                decoration: BoxDecoration(
                  color: AppColor.CartDark,
                  border: Border.all(width: 1, color: AppColor.green1),
                  borderRadius: BorderRadius.circular(AppSize.width * 0.04),
                ),
                child: Center(
                  child: Text(
                    'Open Battery Optimization Settings',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyle.greenFont,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}