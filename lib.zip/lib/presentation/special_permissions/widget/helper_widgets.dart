import 'package:Privio/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';
import 'package:Privio/constant/app_color.dart';
import 'package:Privio/constant/app_style.dart';
import 'package:Privio/constant/risk_level.dart';
import 'package:Privio/generated/app_localizations.dart';
import 'package:Privio/presentation/utils/app_size.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Widget sectionTitle(String text, BuildContext context) {
  return Text(text, style: AppTextStyle.trustTitle(context));
}

Widget paragraph(String text, BuildContext context) {
  return Padding(
    padding: EdgeInsets.only(top: AppSize.height * 0.01),
    child: Text(
      text,
      style: AppTextStyle.trustDescription(context)
          .copyWith(color: context.isDark ? AppColor.green2 : AppColor.green4),
    ),
  );
}

Widget riskBadge(
  BuildContext context, {
  required RiskLevel level,
}) {
  late Color color;
  late String label;
  final l10n = AppLocalizations.of(context)!;

  switch (level) {
    case RiskLevel.highRisk:
      color = Colors.red;
      label = l10n.actionNeeded;
      break;
    case RiskLevel.mediumRisk:
      color = Colors.orange;
      label = l10n.review;
      break;
    case RiskLevel.lowRisk:
      color = Colors.green;
      label = l10n.low;
      break;
    case RiskLevel.noRisk:
      color = Colors.blue;
      label = l10n.secure;
      break;
  }

  return Container(
    padding: EdgeInsets.symmetric(
      horizontal: AppSize.width * 0.03,
      vertical: AppSize.height * 0.008,
    ),
    decoration: BoxDecoration(
      color: color.withAlpha(38),
      borderRadius: BorderRadius.circular(AppSize.width * 0.05),
    ),
    child: Text(label,
        style: AppTextStyle.lastScan(context).copyWith(color: color)),
  );
}

Widget actionButton({
  required BuildContext context,
  required String text,
  required VoidCallback onTap,
}) {
  return GestureDetector(
    onTap: onTap,
    child: Padding(
      padding: EdgeInsets.symmetric(vertical: AppSize.height * 0.018,horizontal: 20.w),
      child: Container(
        width: double.infinity,
        height: 70.h,
        decoration: BoxDecoration(
          color: context.isDark ? AppColor.CartDark : AppColor.btnLight,
          borderRadius: BorderRadius.circular(AppSize.width * 0.03),
          border: Border.all(width: 1.w , color: context.isDark ? AppColor.CartDark : AppColor.borderLight, )
        ),
        child: Center(
          child: Text(
            text,
            style: AppTextStyle.appName(context),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ),
      ),
    ),
  );
}
