import 'package:Privio/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';
import 'package:Privio/constant/app_color.dart';
import 'package:Privio/generated/app_localizations.dart';
import 'package:Privio/presentation/utils/app_size.dart';

class KeepAppButton extends StatelessWidget {
  final bool isKept;
  final VoidCallback onTap;

  const KeepAppButton({
    super.key,
    required this.isKept,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
        padding: EdgeInsets.symmetric(vertical: AppSize.height * 0.017),
        decoration: BoxDecoration(
          color: isKept
              ? Colors.green.withValues(alpha: 0.15)
              : (context.isDark ? AppColor.CartDark : AppColor.btnLight),
          borderRadius: BorderRadius.circular(AppSize.width * 0.04),
          border: Border.all(
            color: isKept
                ? Colors.green
                : (context.isDark ? Colors.white12 : AppColor.borderLight),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isKept ? Icons.verified_rounded : Icons.push_pin_outlined,
              color: isKept ? Colors.green :  (context.isDark?Colors.white70:AppColor.CartDarkBorder),
              size: AppSize.width * 0.055,
            ),
            SizedBox(width: AppSize.width * 0.025),
            Flexible(
              child: Text(
                isKept ? l10n.appIsKept : l10n.keepApp,
                style: TextStyle(
                  color: isKept
                      ? Colors.green
                      : (context.isDark
                          ? Colors.white70
                          : AppColor.CartDarkBorder),
                  fontSize: AppSize.width * 0.035,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
