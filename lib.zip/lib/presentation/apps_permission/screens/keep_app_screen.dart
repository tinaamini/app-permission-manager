import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import 'package:permissions_app/constant/app_color.dart';
import 'package:permissions_app/constant/app_style.dart';
import 'package:permissions_app/logic/app_permission/app_permission_cubit.dart';
import 'package:permissions_app/logic/app_permission/app_permission_state.dart';
import 'package:permissions_app/presentation/apps_permission/widgets/app_tile.dart';
import 'package:permissions_app/presentation/home/widgets/app_bar.dart';
import 'package:permissions_app/presentation/utils/base_screen.dart';
import 'package:permissions_app/presentation/utils/custome_dotsloader.dart';
import 'package:permissions_app/presentation/utils/empty_page_widget.dart';

class KeepAppsScreen extends StatelessWidget {
  const KeepAppsScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;


    return BaseScreen(
      child: Column(
        children: [
          AppBarWidget(
            text: 'KEEP APPS',
            ontap: () => context.pop(),
          ),

          Expanded(
            child: BlocBuilder<AppPermissionCubit, AppPermissionState>(
              builder: (context, state) {
                if (state is! AppPermissionLoaded) {
                  return const  Center(
                      child: CustomDotsLoader(
                          svgPath1:
                          'assets/utils/Property 1=1 (1).svg',
                          svgPath2: 'assets/utils/Property 1=2 (1).svg',
                          svgPath3: 'assets/utils/Property 1=3 (1).svg',
                          svgPath4:
                          'assets/utils/Property 1=4 (1).svg'));
                }

                final cubit = context.read<AppPermissionCubit>();

                final keptApps = [
                  ...state.noRisk,
                  ...state.lowRisk,
                  ...state.mediumRisk,
                  ...state.highRisk,
                ].where((app) => cubit.isAppKept(app.packageName)).toList();

                if (keptApps.isEmpty) {
                  return const Center(
                    child: EmptyPageWidget(text: "NO KEEP APP"),
                  );
                }

                return ListView(
                  padding: EdgeInsets.all(screenWidth * 0.04),
                  children: [
                    Row(
                      children: [
                        SvgPicture.asset("assets/app_permission/tick-square.svg"),
                        SizedBox(
                          width: screenWidth * 0.02,
                        ),
                        Text(
                          "REVIEWED LIST",
                          style: AppTextStyle.greenFont,
                        ),
                      ],
                    ),
                    SizedBox(
                      height: screenHeight * 0.007,
                    ),
                    Text("Marked as Safe", style: AppTextStyle.trustTitle),
                    SizedBox(
                      height: screenHeight * 0.007,
                    ),
                    Text(
                      "These are apps you have manually reviewed.\n"
                          "They will no longer trigger risk warnings unless\n"
                          "their behavior changes significantly.",
                      style: AppTextStyle.trustDescription.copyWith(
                        color: AppColor.green2,
                      ),
                    ),

                    SizedBox(
                      height: screenHeight * (16 / 812),
                    ),
                    ...keptApps.map(
                          (app) => appTile(
                        context,
                        app,
                        actionText: 'Remove',
                        onTap: () => _confirmUnKeep(context, app.packageName),
                      ),
                    ),

                    SizedBox(
                      height: screenHeight * (12 / 812),
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: screenHeight * (12 / 812),),
                      padding: EdgeInsets.all(screenWidth * (12 / 812),),
                      decoration: BoxDecoration(
                        color: AppColor.green1.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(screenWidth * (24 / 812),),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SvgPicture.asset("assets/app_permission/danger.svg"),
                          SizedBox(width: screenWidth * (12 / 812),),

                          Expanded(
                            child: Text(
                              'Removing an app from this list will return it to the '
                                  '"Risk Apps" scan result if it requests sensitive '
                                  'permissions in the future.',
                              style: AppTextStyle.greenWarning,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _confirmUnKeep(BuildContext context, String packageName) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColor.CartDarkBorder,
        title: Text('Remove from Keep', style: AppTextStyle.greenFont),
        content: Text(
          'This app will no longer be trusted and will be analyzed again for potential risks.',
          style: AppTextStyle.trustDescription.copyWith(color: AppColor.green2),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
            child: Text('Cancel', style: AppTextStyle.greenFont),
          ),
          TextButton(
            onPressed: () {
              context.read<AppPermissionCubit>().unkeepApp(packageName);
              Navigator.of(context, rootNavigator: true).pop();
            },
            child: Text('Remove', style: AppTextStyle.greenFont),
          ),
        ],
      ),
    );
  }
}